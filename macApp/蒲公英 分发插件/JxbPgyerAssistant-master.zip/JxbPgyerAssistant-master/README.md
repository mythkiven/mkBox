# JxbPgyerAssistant
依托蒲公英应用测试分发平台，用于XCode的一款插件，方便开发者上传生成二维码。

`此插件已被蒲公英官方收录：http://www.pgyer.com/doc/view/xcode_plugin`

#使用方法
1.打开工程JxbPgyerMan.project，运行即可。

2.关闭XCode，重新启动。

3.在XCode的菜单Window下面的Pgyer Assistant菜单(快捷键打开：shift+control+J)，如图

![](https://raw.githubusercontent.com/JxbSir/JxbPgyerAssistant/master/Shoot/position.png)

4.打开菜单后，先登录蒲公英：

![](https://raw.githubusercontent.com/JxbSir/JxbPgyerAssistant/master/Shoot/login.png)

5.登录成功后，即可使用分发：

![](https://raw.githubusercontent.com/JxbSir/JxbPgyerAssistant/master/Shoot/main.png)

6.双击点击应用的图标会弹出二维码：

![](https://raw.githubusercontent.com/JxbSir/JxbPgyerAssistant/master/Shoot/qr.png)

