//
//  XBPgyerLoginLoading.h
//  JxbPgyerMan
//
//  Created by Peter Jin on https://github.com/JxbSir  15/5/19.
//  Copyright (c) 2015年 Peter Jin .  Mail:i@Jxb.name All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface XBPgyerLoginLoading : NSView
- (void)setLoginName:(NSString*)loginName;
@end
