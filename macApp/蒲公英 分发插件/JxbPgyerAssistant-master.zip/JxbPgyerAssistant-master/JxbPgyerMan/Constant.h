//
//  Constant.h
//  JxbPgyerMan
//
//  Created by Peter Jin on https://github.com/JxbSir  15/5/19.
//  Copyright (c) 2015年 Peter Jin .  Mail:i@Jxb.name All rights reserved.
//

#define mainColor   [NSColor colorWithSRGBRed:164/255. green:211/255. blue:238/255. alpha:1]  //#A4D3EE
